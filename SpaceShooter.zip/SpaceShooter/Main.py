import pygame as pyg
import expansion
from random import *
color1 = randint(0, 255)
color2 = randint(0, 255)
color3 = randint(0, 255)

sap=False
stb=False
rightup=pyg.image.load("Right.png")
leftup=pyg.image.load("Left.png")
up=pyg.image.load("Up.png")
bg=pyg.image.load("bg2.png")
spl1=pyg.image.load("spl1.png")
spl2=pyg.image.load("spl2.png")
spr1=pyg.image.load("spr1.png")
spr2=pyg.image.load("spr2.png")

bomba=False
sps= randint(0,1)
#def strelok(x,y):
sheeps= randint(1, 5)
end=False
hp=3
left=False
right=False
exph=expansion.highex()-70
expw=expansion.widghtex()-65

pyg.init()
window=pyg.display.set_mode((exph,expw))

flag1=False
pyg.display.set_caption("DrAttack")
start_patron=False
width = 100
height = 50
x = exph//2-width
y = expw-height-185
speed = 5
ypatron=y
xsheep=-100
ysheep=randint(60,250)
tsheep=randint(0,1)

if start_patron==False:
    font = pyg.font.Font(None, 60)

    xpatron = x

propusti_up=False
exp=0
run = True
while run:
    pyg.time.delay(1)

    window.blit(bg, (0, 0))
    for event in pyg.event.get():
        if event.type == pyg.QUIT:
            run=False

    keys = pyg.key.get_pressed()
    if ((keys[pyg.K_RIGHT]  or keys[pyg.K_d])and x < exph - width - 1 and end==False):
        x += speed
        right=True

    elif ((keys[pyg.K_LEFT] or keys[pyg.K_a]) and x > 1 and end==False):
        x -= speed
        left=True
    else:
        right=False
        left=False
   # if keys[pyg.K_BACKSLASH]:
   #  if (keys[pyg.K_F2] and sap==False):
   #      exp+=3
   #      xsheep=-100
   #      sap=True
   #  if (keys[pyg.K_F3]):
   #      hp+=1
   #  if (keys[pyg.K_F5]):
   #      hp-=3
   #  if (keys[pyg.K_F6]):
   #      sheeps += 1
   #  if (keys[pyg.K_F7]):
   #      sheeps -= 1
   #  if (keys[pyg.K_F10]):
   #      speed+=1
   #  if (keys[pyg.K_F12]):
   #      speed-=1
    if sap==True:
        sap=False
    if (keys[pyg.K_UP] or keys[pyg.K_w] or keys[pyg.K_SPACE]) and end==False:
        if start_patron==False:
            xpatron=x+25
        if start_patron==False:
            start_patron=True
    if start_patron==True:
        if ypatron<=0:
            start_patron=False
            ypatron=y


        ypatron-=10

        # if propusti_up:
        #     propusti_up=False
        # else:
        #     propusti_up=True
        #     ypatron = y
        #     while ypatron>1:
        #         print(ypatron)
        #
        #         #pyg.time.delay(1)
        #
        #         window.fill((0, 0, 0))
        #
        #
        #         ypatron-=1
        #
        #
        #         pyg.display.update()


        if sps==1:
            flag1==True
        else:
            flag1==False
    if xsheep > exph+100:
        flag1=True
    if flag1:
        xsheep -= sheeps
        if tsheep==0:
            window.blit(spl1,(xsheep,ysheep))
        if tsheep==1:
            window.blit(spl2,(xsheep,ysheep))
        if xsheep <=-150:
            flag1=False
    else :
        xsheep += sheeps
        if tsheep==0:
            window.blit(spr1,(xsheep,ysheep))
        if tsheep==1:
            window.blit(spr2,(xsheep,ysheep))
        #strelok(x,y)

    txt1="Score:"+str(exp)
    text1 = font.render(txt1, 1, (255, 255, 255))
    place1 = text1.get_rect(center=(exph - 100, expw - 970))

    if end==False:
        txt2 = "HP:" + str(hp)
        if hp<10:
            xpl=50
            ypl=40
        else:
            xpl = 80
            ypl = 40
    else:
        txt2="GAME OVER!"
        ypl = 40
        xpl = 140
        window.blit(text2, place2)

    text2 = font.render(txt2, 1, (255, 0, 0))
    place2 = text2.get_rect(center=(xpl, ypl))
    window.blit(text2, place2)
    window.blit(text1, place1)

    if start_patron and ypatron>0:

        pyg.draw.circle(window, (0, 0, 255), (xpatron, ypatron), 5)
    if left:
        window.blit(leftup, (x, y))

    elif right:
        window.blit(rightup, (x, y))
    else:
        window.blit(up, (x, y))
    #pyg.draw.rect(window, (128, 128, 128), (x, y, width, height))
    if (xpatron >= xsheep and xpatron <= xsheep + width) and (ypatron >= ysheep and ypatron < ysheep + height):
        print(123)
        xsheep = -100
        xpatron=50000
        if tsheep == 0:
            exp += 1
        else:
            exp += 2
        color1 = randint(0, 255)
        color2 = randint(0, 255)
        color3 = randint(0, 255)
        if tsheep == 0:
            if exp>=10:
                sheeps = randint(5, 5)
            else:
                sheeps = randint(1, 1)
        else:
            if exp>=10:
                sheeps = randint(5, 5)
            else:
                sheeps = randint(1, 1)
        # sheeps= randint(15,15)
        sps = randint(0, 1)
        ysheep = randint(60, 250)
        tsheep = randint(0, 1)

    if bomba :
        print(4)
        ybom+=2
        pyg.draw.circle(window, (255, 0, 0), (xbom, ybom), 10)
        if ybom >= expw-200:
            xbom=60000
        if xbom>=x and xbom<=x+width and ybom>y and ybom<y+height:
            hp-=1
            bomba=False
            stb=False
            print("HP",hp)

    if xsheep == x and stb==False:
        print(0)
        xbom=xsheep
        ybom=ysheep
        bomba=True
        stb=True
    if hp <= 0:
        txt2 = "GAME OVER"
        end=True
    pyg.display.update()
pyg.quit()