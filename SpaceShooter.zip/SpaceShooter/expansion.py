import tkinter as tk
root = tk.Tk()
expinf=[]

def highex():
    exphigh = root.winfo_screenwidth()
    return(exphigh)

def widghtex():
    expwidght = root.winfo_screenheight()
    return(expwidght)
